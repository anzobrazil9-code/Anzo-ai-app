import 'package:flutter/material.dart';
import '../presentation/main_chat_interface/main_chat_interface.dart';

class AppRoutes {
  // TODO: Add your routes here
  static const String initial = '/';
  static const String mainChatInterface = '/main-chat-interface';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const MainChatInterface(),
    mainChatInterface: (context) => const MainChatInterface(),
    // TODO: Add your other routes here
  };
}

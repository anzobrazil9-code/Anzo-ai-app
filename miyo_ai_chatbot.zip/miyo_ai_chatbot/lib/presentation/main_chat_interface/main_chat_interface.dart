import 'dart:async';
import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart'; // Add this import
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/chat_input_widget.dart';
import './widgets/empty_chat_widget.dart';
import './widgets/message_bubble_widget.dart';
import './widgets/network_status_widget.dart';

class MainChatInterface extends StatefulWidget {
  const MainChatInterface({Key? key}) : super(key: key);

  @override
  State<MainChatInterface> createState() => _MainChatInterfaceState();
}

class _MainChatInterfaceState extends State<MainChatInterface> {
  final ScrollController _scrollController = ScrollController();
  final List<Map<String, dynamic>> _messages = [];
  final Dio _dio = Dio();
  bool _isLoading = false;
  bool _isConnected = true;
  bool _isRetrying = false;
  StreamSubscription<ConnectivityResult>? _connectivitySubscription;
  final List<Map<String, dynamic>> _offlineQueue = [];

  // Mock AI responses for demonstration
  final List<String> _mockResponses = [
    "Hello! I'm Anzo, your AI companion. How can I help you today?",
    "That's an interesting question! Let me think about that for a moment.",
    "I'd be happy to help you with that. Here's what I think...",
    "Great question! Based on my knowledge, I can tell you that...",
    "I understand what you're asking. Let me provide you with a detailed explanation.",
    "That's a fascinating topic! I love discussing these kinds of questions.",
    "I'm here to help! Let me break this down for you step by step.",
    "Thank you for asking! This is something I can definitely assist you with.",
    "मैं आपकी मदद करने के लिए यहाँ हूँ! आपका सवाल बहुत अच्छा है।",
    "यह एक दिलचस्प विषय है। मैं इसके बारे में विस्तार से बता सकता हूँ।",
  ];

  @override
  void initState() {
    super.initState();
    _loadChatHistory();
    _initConnectivity();
    _setupScrollListener();
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _connectivitySubscription?.cancel();
    super.dispose();
  }

  void _setupScrollListener() {
    _scrollController.addListener(() {
      if (_scrollController.position.userScrollDirection ==
          ScrollDirection.forward) {
        FocusScope.of(context).unfocus();
      }
    });
  }

  Future<void> _initConnectivity() async {
    final connectivityResult = await Connectivity().checkConnectivity();
    setState(() {
      _isConnected = connectivityResult != ConnectivityResult.none;
    });

    _connectivitySubscription =
        Connectivity().onConnectivityChanged.listen((result) {
      final wasConnected = _isConnected;
      setState(() {
        _isConnected = result != ConnectivityResult.none;
      });

      if (!wasConnected && _isConnected) {
        _processOfflineQueue();
      }
    });
  }

  Future<void> _loadChatHistory() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final chatHistory = prefs.getString('chat_history');
      if (chatHistory != null) {
        final List<dynamic> decodedHistory = json.decode(chatHistory);
        setState(() {
          _messages.clear();
          _messages.addAll((decodedHistory)
              .map((item) => {
                    'message': item['message'] as String,
                    'isUser': item['isUser'] as bool,
                    'timestamp': DateTime.parse(item['timestamp'] as String),
                    'id': item['id'] as String,
                  })
              .toList());
        });
      }
    } catch (e) {
      debugPrint('Error loading chat history: $e');
    }
  }

  Future<void> _saveChatHistory() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final chatHistory = _messages
          .map((message) => {
                'message': message['message'],
                'isUser': message['isUser'],
                'timestamp':
                    (message['timestamp'] as DateTime).toIso8601String(),
                'id': message['id'],
              })
          .toList();
      await prefs.setString('chat_history', json.encode(chatHistory));
    } catch (e) {
      debugPrint('Error saving chat history: $e');
    }
  }

  Future<void> _sendMessage(String message) async {
    if (message.trim().isEmpty) return;

    final userMessage = {
      'message': message,
      'isUser': true,
      'timestamp': DateTime.now(),
      'id': DateTime.now().millisecondsSinceEpoch.toString(),
    };

    setState(() {
      _messages.add(userMessage);
      _isLoading = true;
    });

    _scrollToBottom();
    await _saveChatHistory();

    if (!_isConnected) {
      _offlineQueue.add(userMessage);
      setState(() {
        _isLoading = false;
      });
      return;
    }

    try {
      await _getAIResponse(message);
    } catch (e) {
      _handleMessageError();
    }
  }

  Future<void> _getAIResponse(String userMessage) async {
    try {
      // Simulate API delay
      await Future.delayed(Duration(milliseconds: 1500));

      // Mock AI response selection based on message content
      String aiResponse;
      final lowerMessage = userMessage.toLowerCase();

      if (lowerMessage.contains('hello') ||
          lowerMessage.contains('hi') ||
          lowerMessage.contains('नमस्ते')) {
        aiResponse =
            "Hello! I'm Anzo, your AI companion. How can I help you today?";
      } else if (lowerMessage.contains('story') ||
          lowerMessage.contains('कहानी')) {
        aiResponse =
            "I'd love to tell you a story! Once upon a time, in a digital realm far away, there lived an AI named Anzo who loved helping people discover new things every day...";
      } else if (lowerMessage.contains('help') ||
          lowerMessage.contains('मदद')) {
        aiResponse =
            "I'm here to help! I can assist you with explanations, answer questions, provide advice, tell stories, or just have a friendly conversation. What would you like to know?";
      } else if (lowerMessage.contains('hindi') ||
          lowerMessage.contains('हिंदी')) {
        aiResponse =
            "हाँ, मैं हिंदी में भी बात कर सकता हूँ! आप मुझसे हिंदी या अंग्रेजी में कोई भी सवाल पूछ सकते हैं। मैं आपकी मदद करने के लिए यहाँ हूँ।";
      } else {
        // Random response for other messages
        aiResponse =
            _mockResponses[DateTime.now().millisecond % _mockResponses.length];
      }

      final aiMessage = {
        'message': aiResponse,
        'isUser': false,
        'timestamp': DateTime.now(),
        'id': DateTime.now().millisecondsSinceEpoch.toString(),
      };

      setState(() {
        _messages.add(aiMessage);
        _isLoading = false;
      });

      _scrollToBottom();
      await _saveChatHistory();
    } catch (e) {
      _handleMessageError();
    }
  }

  void _handleMessageError() {
    setState(() {
      _isLoading = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Failed to send message. Please try again.'),
        action: SnackBarAction(
          label: 'Retry',
          onPressed: () {
            if (_messages.isNotEmpty && _messages.last['isUser']) {
              _getAIResponse(_messages.last['message']);
            }
          },
        ),
      ),
    );
  }

  Future<void> _processOfflineQueue() async {
    if (_offlineQueue.isEmpty) return;

    setState(() {
      _isRetrying = true;
    });

    for (final message in _offlineQueue) {
      try {
        await _getAIResponse(message['message']);
      } catch (e) {
        debugPrint('Error processing offline message: $e');
      }
    }

    _offlineQueue.clear();
    setState(() {
      _isRetrying = false;
    });
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _refreshChat() async {
    HapticFeedback.lightImpact();
    await Future.delayed(Duration(milliseconds: 500));
  }

  void _deleteMessage(String messageId) {
    setState(() {
      _messages.removeWhere((message) => message['id'] == messageId);
    });
    _saveChatHistory();
  }

  void _clearChatHistory() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Clear Chat History',
          style: AppTheme.lightTheme.textTheme.titleMedium,
        ),
        content: Text(
          'Are you sure you want to clear all chat history? This action cannot be undone.',
          style: AppTheme.lightTheme.textTheme.bodyMedium,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                _messages.clear();
              });
              _saveChatHistory();
              Navigator.pop(context);
            },
            child: Text('Clear'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.secondary,
      body: Column(
        children: [
          // App Bar
          Container(
            padding: EdgeInsets.symmetric(horizontal: 4.w),
            decoration: BoxDecoration(
              color: AppTheme.secondary,
              border: Border(
                bottom: BorderSide(
                  color: AppTheme.border,
                  width: 1,
                ),
              ),
            ),
            child: SafeArea(
              bottom: false,
              child: Container(
                height: 8.h,
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        'Anzo',
                        style: AppTheme.lightTheme.textTheme.headlineSmall
                            ?.copyWith(
                          fontWeight: FontWeight.w700,
                          color: AppTheme.primary,
                        ),
                      ),
                    ),
                    PopupMenuButton<String>(
                      icon: CustomIconWidget(
                        iconName: 'more_vert',
                        color: AppTheme.primary,
                        size: 24,
                      ),
                      onSelected: (value) {
                        if (value == 'clear') {
                          _clearChatHistory();
                        }
                      },
                      itemBuilder: (context) => [
                        PopupMenuItem(
                          value: 'clear',
                          child: Row(
                            children: [
                              CustomIconWidget(
                                iconName: 'delete_outline',
                                color: AppTheme.primary,
                                size: 20,
                              ),
                              SizedBox(width: 2.w),
                              Text('Clear Chat'),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Network Status
          NetworkStatusWidget(
            isConnected: _isConnected,
            isRetrying: _isRetrying,
            onRetry: _processOfflineQueue,
          ),

          // Chat Messages
          Expanded(
            child: _messages.isEmpty
                ? EmptyChatWidget()
                : RefreshIndicator(
                    onRefresh: _refreshChat,
                    color: AppTheme.primary,
                    child: ListView.builder(
                      controller: _scrollController,
                      padding: EdgeInsets.only(top: 2.h, bottom: 2.h),
                      itemCount: _messages.length,
                      itemBuilder: (context, index) {
                        final message = _messages[index];
                        return MessageBubbleWidget(
                          message: message['message'],
                          isUser: message['isUser'],
                          timestamp: message['timestamp'],
                          onDelete: () => _deleteMessage(message['id']),
                        );
                      },
                    ),
                  ),
          ),

          // Chat Input
          ChatInputWidget(
            onSendMessage: _sendMessage,
            isLoading: _isLoading,
          ),
        ],
      ),
    );
  }
}
